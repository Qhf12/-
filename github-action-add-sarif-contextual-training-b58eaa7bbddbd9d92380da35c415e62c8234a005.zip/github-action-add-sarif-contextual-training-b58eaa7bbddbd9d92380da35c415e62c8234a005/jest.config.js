module.exports = {
    setupFiles: ['./.jest/setEnvVars.js']
};
