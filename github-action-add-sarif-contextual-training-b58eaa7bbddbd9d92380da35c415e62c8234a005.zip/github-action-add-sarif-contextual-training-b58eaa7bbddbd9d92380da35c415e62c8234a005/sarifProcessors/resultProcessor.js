"use strict";

async function process(run) {
    return run;
}

module.exports = {
    process
};
